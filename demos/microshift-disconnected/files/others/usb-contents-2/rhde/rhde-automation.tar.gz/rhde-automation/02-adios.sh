#!/bin/bash

touch /root/ADIOS
echo "ADIOS!"
