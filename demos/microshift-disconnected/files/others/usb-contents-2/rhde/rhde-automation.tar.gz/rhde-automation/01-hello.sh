#!/bin/bash

touch /root/HECHO

echo "HECHO!"
